//
//  TextToMeTests.swift
//  TextToMeTests
//
//  Created by Valentin Glukhov on 24.05.2025.
//

import Testing
@testable import TextToMe

struct TextToMeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
