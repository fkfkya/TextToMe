import Foundation

struct User {
    let nickname: String
    let uuid: String
}
